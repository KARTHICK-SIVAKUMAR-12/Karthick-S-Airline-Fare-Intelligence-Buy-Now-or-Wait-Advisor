import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import joblib
import pandas as pd
import streamlit as st
from src.predict import predict_price
st.set_page_config(page_title='Airline Fare Intelligence',layout='wide')
st.title('✈️ Airline Fare Intelligence')
st.caption('Fare estimation and route exploration using Clean_Dataset.csv. Not a validated buy-now-or-wait forecast.')
@st.cache_resource
def load_bundle(): return joblib.load(ROOT/'models/fare_model.joblib')
@st.cache_data
def load_data(): return pd.read_csv(ROOT/'data/raw/Clean_Dataset.csv')
bundle=load_bundle();df=load_data();cats=bundle['categories']
with st.form('predict'):
    a,b,c=st.columns(3)
    airline=a.selectbox('Airline',cats['airline'])
    source=a.selectbox('Origin',cats['source_city'])
    destination=a.selectbox('Destination',cats['destination_city'],index=min(1,len(cats['destination_city'])-1))
    travel_class=b.selectbox('Class',cats['class'])
    stops=b.selectbox('Stops',cats['stops'])
    departure=b.selectbox('Departure period',cats['departure_time'])
    arrival=c.selectbox('Arrival period',cats['arrival_time'])
    duration=c.number_input('Duration (hours)',min_value=.5,max_value=30.,value=2.5,step=.25)
    days=c.slider('Days until departure',1,49,21)
    go=st.form_submit_button('Estimate fare')
if go:
    if source==destination:st.error('Origin and destination must differ.')
    else:
        row={'airline':airline,'source_city':source,'destination_city':destination,'departure_time':departure,'arrival_time':arrival,'stops':stops,'class':travel_class,'duration':duration,'days_left':days}
        st.metric('Estimated fare',f'₹{predict_price(row,bundle):,.0f}')
        st.info('Estimate only. No verified 7-day rise probability or historical savings claim is available.')
st.subheader('Observed fare trends')
route=df[(df.source_city==source)&(df.destination_city==destination)&(df['class']==travel_class)]
if len(route):
    curve=route.groupby('days_left').price.median().sort_index()
    st.line_chart(curve)
    st.caption(f'{len(route):,} historical dataset rows in this selection; observations are not linked to dated departures.')
else:st.warning('No rows for this route and class.')
