import numpy as np
import pandas as pd
CATEGORICAL = ['airline','source_city','destination_city','departure_time','arrival_time','stops','class']
FEATURES = CATEGORICAL + ['duration','days_left']
def clean_and_engineer(raw):
    df=raw.drop(columns=['Unnamed: 0'],errors='ignore').copy()
    required=set(FEATURES+['price'])
    missing=required-set(df.columns)
    if missing: raise ValueError(f'Missing required columns: {sorted(missing)}')
    for col in CATEGORICAL:
        df[col]=df[col].astype('string').str.strip().fillna('Unknown')
    for col in ['duration','days_left','price']:
        df[col]=pd.to_numeric(df[col],errors='coerce')
    df=df.dropna(subset=FEATURES+['price'])
    df=df[(df.price>0)&(df.days_left.between(1,365))&(df.duration>0)].copy()
    df['route']=df.source_city+' → '+df.destination_city
    return df.reset_index(drop=True)
def model_frame(df):
    X=df[FEATURES].copy()
    for c in CATEGORICAL: X[c]=X[c].astype('category')
    return X
