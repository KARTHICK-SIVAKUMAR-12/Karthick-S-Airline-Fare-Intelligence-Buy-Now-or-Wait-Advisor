from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from src.train import ROOT
from src.features import model_frame

def make_charts(df,test,metrics,model):
    dest=ROOT/'outputs/figures';dest.mkdir(parents=True,exist_ok=True)
    def save(n,title):
        plt.title(title);plt.tight_layout();plt.savefig(dest/f'chart{n:02d}.png',dpi=125);plt.close()
    df.groupby('class').price.apply(lambda s:s.sample(min(len(s),5000),random_state=1)).reset_index(level=0).boxplot(column='price',by='class');plt.yscale('log');plt.suptitle('');save(1,'Fare distribution by class (log scale)')
    t=df.groupby(['route','days_left']).price.median().unstack(0);t.plot(figsize=(11,5),legend=False);plt.xlabel('Days left');plt.ylabel('Median fare INR');save(2,'Route fare curves (observed)')
    df.groupby('airline').price.median().sort_values().plot.bar();plt.ylabel('Median INR');save(3,'Median fare by airline (unadjusted)')
    df.groupby(['departure_time','class']).price.median().unstack().plot.bar();plt.ylabel('Median INR');save(4,'Fare by departure period and class (weekday unavailable)')
    df.groupby('days_left').price.median().plot();plt.ylabel('Median INR');save(5,'Median fare by days left (festival dates unavailable)')
    df.groupby(['days_left','class']).price.median().unstack().plot();plt.ylabel('Median INR');save(6,'Fare curve by travel class (festival dates unavailable)')
    df.groupby('stops').price.median().plot.bar();plt.ylabel('Median INR');save(7,'Fare by stops (rise labels unavailable)')
    df.groupby('duration').price.median().sort_index().rolling(10,min_periods=1).mean().plot();plt.xlabel('Duration hours');plt.ylabel('Rolling median INR');save(8,'Fare vs journey duration (Optuna history unavailable)')
    metrics.set_index('model').MAPE_pct.plot.bar();plt.ylabel('Test MAPE %');save(9,'Model comparison: grouped holdout')
    sample=test.sample(min(len(test),6000),random_state=4);plt.scatter(sample.price,sample.predicted_price,s=2,alpha=.25);plt.xlabel('Actual INR');plt.ylabel('Predicted INR');save(10,'Actual vs predicted fare')
    if hasattr(model,'feature_importances_'):
        try:
            import shap
            from src.features import model_frame
            X=model_frame(df.sample(min(len(df),350),random_state=7))
            explainer=shap.TreeExplainer(model)
            values=explainer.shap_values(X)
            shap.summary_plot(values,X,plot_type='bar',show=False)
            save(11,'SHAP mean absolute contribution (log fare)')
        except Exception as exc:
            print('SHAP unavailable, using model feature importance:',exc)
            pd.Series(model.feature_importances_,index=model_frame(df).columns).sort_values().plot.barh()
            save(11,'Model feature importance (SHAP unavailable)')
    else:
        df.groupby('days_left').price.median().plot()
        save(11,'Fare by days left (no tree SHAP)')
    df.groupby(['days_left','stops']).price.median().unstack().plot();plt.ylabel('Median INR');save(12,'Fare curves by stops (festival unavailable)')
    df.groupby('days_left').price.agg(['median','mean']).plot();plt.ylabel('Fare INR');save(13,'Mean vs median fare (no decision threshold)')
    df.groupby('class').price.agg(['median','mean']).plot.bar();plt.ylabel('Fare INR');save(14,'Class price summary (no rise classifier)')
    error=(test.predicted_price-test.price);plt.hist(error.clip(-20000,20000),bins=65);plt.xlabel('Prediction error INR');save(15,'Prediction error histogram (not confusion matrix)')
    df.groupby('route').price.median().sort_values().tail(12).plot.barh();plt.xlabel('Median INR');save(16,'Highest-median-fare routes (no backtest)')
    print('Generated',len(list(dest.glob('chart*.png'))),'descriptive and model charts')
if __name__=='__main__':
    from src.train import train
    make_charts(*train())
