from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from src.features import model_frame
ROOT=Path(__file__).resolve().parents[1]
def predict_price(values,bundle=None):
    bundle=bundle or joblib.load(ROOT/'models/fare_model.joblib')
    row=pd.DataFrame([values]);X=model_frame(row)
    return float(np.exp(bundle['model'].predict(X)[0]))
