import json
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import GroupShuffleSplit
from sklearn.metrics import mean_absolute_error, mean_absolute_percentage_error, r2_score
from sklearn.dummy import DummyRegressor
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.linear_model import Ridge
from sklearn.pipeline import Pipeline
from lightgbm import LGBMRegressor
from src.features import clean_and_engineer, model_frame, FEATURES, CATEGORICAL
ROOT=Path(__file__).resolve().parents[1]
def train():
    raw=pd.read_csv(ROOT/'data/raw/Clean_Dataset.csv')
    df=clean_and_engineer(raw)
    # Flight number is used ONLY for grouping; never as a predictive input.
    groups=df['flight'].astype(str) if 'flight' in df else pd.Series(np.arange(len(df)))
    gss=GroupShuffleSplit(n_splits=1,test_size=.20,random_state=42)
    train_idx,test_idx=next(gss.split(df,groups=groups))
    train_df,test_df=df.iloc[train_idx].copy(),df.iloc[test_idx].copy()
    X_train,X_test=model_frame(train_df),model_frame(test_df)
    y_train,y_test=np.log(train_df.price),test_df.price.to_numpy()
    models={
      'Median baseline':DummyRegressor(strategy='median'),
      'Ridge':Pipeline([('prep',ColumnTransformer([('cat',OneHotEncoder(handle_unknown='ignore'),CATEGORICAL)],remainder='passthrough')),('model',Ridge(alpha=10.0))]),
      'LightGBM':LGBMRegressor(n_estimators=220,learning_rate=.065,num_leaves=31,max_depth=-1,random_state=42,verbosity=-1,n_jobs=4)
    }
    rows=[]; predictions={}
    for name,model in models.items():
        model.fit(X_train,y_train)
        pred=np.exp(model.predict(X_test))
        predictions[name]=pred
        rows.append({'model':name,'MAE_INR':round(mean_absolute_error(y_test,pred),2),'MAPE_pct':round(mean_absolute_percentage_error(y_test,pred)*100,3),'R2':round(r2_score(y_test,pred),4)})
    metrics=pd.DataFrame(rows).sort_values('MAPE_pct')
    best_name=metrics.iloc[0]['model'];best=models[best_name]
    (ROOT/'models').mkdir(exist_ok=True)
    joblib.dump({'model':best,'features':FEATURES,'categories':{c:sorted(df[c].astype(str).unique().tolist()) for c in CATEGORICAL},'model_name':best_name},ROOT/'models/fare_model.joblib')
    (ROOT/'outputs/reports').mkdir(parents=True,exist_ok=True)
    metrics.to_csv(ROOT/'outputs/reports/model_metrics.csv',index=False)
    test_out=test_df[['airline','source_city','destination_city','class','days_left','price']].copy()
    test_out['predicted_price']=predictions[best_name]
    test_out.to_csv(ROOT/'outputs/reports/test_predictions.csv',index=False)
    summary={'dataset_rows':int(len(df)),'unique_flight_numbers':int(groups.nunique()),'test_rows':int(len(test_df)),'best_model':best_name,'test_MAPE_pct':float(metrics.iloc[0].MAPE_pct),'test_MAE_INR':float(metrics.iloc[0].MAE_INR),'test_R2':float(metrics.iloc[0].R2),'split':'GroupShuffleSplit by flight number; no date-based split possible','limitations':['No search_date or departure_date','No valid seven-day rise label','No historical buy/wait backtest or festival analysis']}
    (ROOT/'outputs/reports/summary.json').write_text(json.dumps(summary,indent=2))
    print(metrics.to_string(index=False));print(json.dumps(summary,indent=2))
    return df,test_out,metrics,best
if __name__=='__main__':train()
