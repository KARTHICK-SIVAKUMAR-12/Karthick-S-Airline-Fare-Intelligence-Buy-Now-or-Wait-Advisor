import pandas as pd
import pytest
from src.features import clean_and_engineer,model_frame,FEATURES

def sample():
 return pd.DataFrame([{'airline':'SpiceJet','flight':'SG-1','source_city':'Delhi','destination_city':'Mumbai','departure_time':'Morning','arrival_time':'Evening','stops':'zero','class':'Economy','duration':2.5,'days_left':21,'price':5000}])
def test_clean():
 d=clean_and_engineer(sample());assert len(d)==1 and d.price.iloc[0]==5000
 assert list(model_frame(d).columns)==FEATURES
def test_invalid_price():
 d=sample();d.loc[0,'price']=0;assert clean_and_engineer(d).empty
def test_missing_column():
 with pytest.raises(ValueError):clean_and_engineer(sample().drop(columns=['price']))
def test_no_date_fabrication():
 assert 'search_date' not in clean_and_engineer(sample()).columns
