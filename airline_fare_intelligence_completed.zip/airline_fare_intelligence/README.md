# Airline Fare Intelligence — Adapted Project

**Dataset:** `Clean_Dataset.csv`, 300,153 rows, 30 origin–destination routes, 6 airlines.

## Scope and integrity
This is an **adapted fare regression and exploratory analytics project**, not the exact historical flight-tracking assignment. The dataset has no `search_date`, `departure_date`, or dated journey identifier. Repeated flight numbers **cannot** be treated as weekly observations of the same journey. Therefore the project **does not claim** a real seven-day >5% fare-rise classifier, holiday effect, historical savings, regret, or validated buy-now-or-wait decision. The 16 numbered figures include clearly labeled alternative charts where the original handbook chart is unsupported. SHAP is used for the LightGBM model where available; a clearly labeled fallback is used otherwise.

## Quick start
```bash
pip install -r requirements.txt
python -m src.train
python -m src.visualize
PYTHONPATH=. python -m pytest -q
streamlit run app/app.py
```

Colab: open `Airline_Fare_Intelligence_Colab.ipynb` and run all cells. The notebook can use the CSV already in `data/raw/` or request an upload if missing.

## Leakage safeguards
Group-disjoint 80/20 holdout by **flight number**. Flight number is excluded from model predictors. This is not a chronological holdout, and there may still be similar itineraries across groups. Reported metrics describe this holdout only.

## Outputs
- `models/fare_model.joblib`: fitted model and categorical options
- `outputs/reports/model_metrics.csv`, `summary.json`, `test_predictions.csv`
- `outputs/figures/chart01.png` through `chart16.png`
- `app/app.py`: interactive fare estimator and observed curves
- `tests/test_features.py`: basic automated tests

## Insights to validate after running
1. Compare median fares by travel class.
2. Compare observed route-specific fare curves across days left.
3. Compare airlines using raw medians (not causal airline premiums).
4. Review errors by fare band and class.
5. Examine SHAP contributions and their limitations.

## Recommendations
1. Use estimated fares as reference prices, not guaranteed quotations.
2. Collect dated flight-level search snapshots before attempting rise classification or buy/wait advice.
3. Monitor out-of-sample MAPE by route/class and retrain as new data arrives.
